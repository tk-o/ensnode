--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.ens_names DROP CONSTRAINT IF EXISTS ens_names_pkey;
DROP TABLE IF EXISTS public.ens_names;
SET default_table_access_method = heap;

--
-- Name: ens_names; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ens_names (
    hash character varying NOT NULL,
    name character varying NOT NULL
);


--
-- Data for Name: ens_names; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ens_names (hash, name) FROM stdin;
0x9dd2c369a187b4e6b9c402f030e50743e619301ea62aa4c0737d4ef7e10a3d49	xyz
0x4f5b812789fc606be1b3b16908db13fc7a9adf7ca72641f84d75b47069d3d7f0	eth
0x9c22ff5f21f0b81b113e63f7db6da94fedef11b2119b4088b89664fb9a3cb658	test
0xb7ccb6878fbded310d2d05350bca9c84568ecb568d4b626c83e0508c3193ce89	legacy
0xe5e14487b78f85faa6e1808e89246cf57dd34831548ff2e6097380d98db2504a	addr
0xdec08c9dbbdd0890e300eb5062089b2d4b1c40e3673bbccb5423f7b37dcf9a9c	reverse
\.
